<?php

namespace App\Controller;

use App\Entity\Article;
use App\Form\ArticleType;
use App\Repository\ArticleRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\File\Exception\FileException;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;


/**
 * @Route("/article", name="article")
 */
class ArticleController extends AbstractController
{
    /**
     * @Route("/", name="index")
     */
    public function index(): Response
    {

        $articles = $this->getDoctrine()->getRepository(Article::class)->findAll();

        return $this->render('article/index.html.twig', [
            'articles' => $articles
        ]);
    }

    /**
     * @Route("/show/{id}", name="show")
     */
    public function show(Article $article): Response
    {


        return $this->render('article/show.html.twig', [
            'article' => $article
        ]);
    }

    /**
     * @Route("/add", name="ajout_article")
     * @param Request $request
     * @return Response
     */
    public function add(Request $request): Response
    {
        $article = new Article();
        $form = $this->createForm(ArticleType::class, $article);

        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){

            if($article->getImgSrc()){
                $file = $form->get('imgSrc')->getData();
                $fileName = uniqid('image', true) . '.' . $file->guessExtension();

                try{
                    $file->move(
                        $this->getParameter('img_folder'), $fileName
                    );
                }
                catch(FileException $e){
                    return new Response($e->getMessage());
                }

                $article->setImgSrc($fileName);
            }

            $article->setDateAjout(new \DateTime());



            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($article);
            $entityManager->flush();

            return $this->redirectToRoute('articleindex');
        }


        return $this->render('article/add.html.twig', [
            'form' => $form->createView()
        ]);
    }

    /**
     * @Route("/edit/{id}", name="edit")
     * @param Article $article
     * @param Request $request
     * @return Response
     */
    public function edit(Article $article, Request $request): Response
    {
        $form = $this->createForm(ArticleType::class, $article);
        $form->handleRequest($request);



        if($form->isSubmitted() && $form->isValid()){

            if($article->getImgSrc() !== null){
                $file = $form->get('imgSrc')->getData();
                $fileName = uniqid('image', true) . '.' . $file->guessExtension();

                try{
                    $file->move(
                        $this->getParameter('img_folder'), $fileName
                    );
                }
                catch(FileException $e){
                    return new Response($e->getMessage());
                }

                $article->setImgSrc($fileName);
            }
            else {
                $uow = $this->getDoctrine()->getManager()->getUnitOfWork();
                $oldArticle = $uow->getOriginalEntityData($article);
                $article->setImgSrc($oldArticle['imgSrc']);
            }

            $article->setDateAjout(new \DateTime());


            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($article);
            $entityManager->flush();

            return $this->redirectToRoute('articleindex');
        }


        return $this->render('article/edit.html.twig', [
            'form' => $form->createView(),
            'article' => $article
        ]);
    }


    /**
     * @Route("/delete/{id}", name="delete")
     * @param Article $article
     * @return Response
     */
    public function delete(Article $article): Response
    {

        $entityManager = $this->getDoctrine()->getManager();
        $entityManager->remove($article);
        $entityManager->flush();


        return $this->redirectToRoute('articleindex');

    }

}
